# Camphish
A tool for hacking webcams

## How to use
```
git clone https://github.com/Kihyu/Camphish.git
cd Camphish
sudo chmod +x camphish.sh
./camphish.sh
```
